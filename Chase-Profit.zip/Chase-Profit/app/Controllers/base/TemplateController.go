package base

//func GetCookieByName(urlStr string) (*http.Cookie, error) {
//	u, err := url.Parse(urlStr)
//	if err != nil {
//		return nil, err
//	}
//
//	cookies := client.Jar.Cookies(u)
//	for _, cookie := range cookies {
//		if cookie.Name == cookieName {
//			return cookie, nil
//		}
//	}
//
//	return nil, fmt.Errorf("cookie %s not found", cookieName)
//}
